python -m sftp_auto_sync.app.main
pause