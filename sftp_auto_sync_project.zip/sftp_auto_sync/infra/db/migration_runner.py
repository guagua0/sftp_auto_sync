from __future__ import annotations

from pathlib import Path

from sftp_auto_sync.infra.db.connection_factory import ConnectionFactory


def run_migrations(connection_factory: ConnectionFactory, schema_path: str | Path | None = None) -> None:
    schema_file = Path(schema_path) if schema_path else Path(__file__).with_name('schema.sql')
    sql = schema_file.read_text(encoding='utf-8')
    with connection_factory.connect() as conn:
        conn.executescript(sql)
        conn.commit()
