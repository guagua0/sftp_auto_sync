from __future__ import annotations

import logging
from datetime import datetime, timezone, timedelta
from logging.handlers import RotatingFileHandler

from sftp_auto_sync.app.app_paths import AppPaths
from sftp_auto_sync.app.constants import LOG_BACKUP_COUNT, LOG_MAX_BYTES

BEIJING_TZ = timezone(timedelta(hours=8))


class BeijingTimeFormatter(logging.Formatter):
    def formatTime(self, record, datefmt=None):
        dt = datetime.fromtimestamp(record.created, tz=BEIJING_TZ)
        if datefmt:
            return dt.strftime(datefmt)
        return dt.strftime('%Y/%m/%d %H:%M:%S')


class SignalLogHandler(logging.Handler):
    def __init__(self, signals=None):
        super().__init__()
        self._signals = signals

    def emit(self, record: logging.LogRecord) -> None:
        if self._signals is None:
            return
        try:
            self._signals.log_message.emit(
                {
                    'level': record.levelname,
                    'message': self.format(record),
                    'logger': record.name,
                }
            )
        except Exception:
            return


def setup_logging(paths: AppPaths, signals=None) -> logging.Logger:
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    logger.handlers.clear()
    formatter = BeijingTimeFormatter('%(asctime)s | %(levelname)s | %(name)s | %(threadName)s | %(message)s')

    app_handler = RotatingFileHandler(paths.logs_dir / 'app.log', maxBytes=LOG_MAX_BYTES, backupCount=LOG_BACKUP_COUNT, encoding='utf-8')
    app_handler.setLevel(logging.INFO)
    app_handler.setFormatter(formatter)
    logger.addHandler(app_handler)

    error_handler = RotatingFileHandler(paths.logs_dir / 'error.log', maxBytes=LOG_MAX_BYTES, backupCount=LOG_BACKUP_COUNT, encoding='utf-8')
    error_handler.setLevel(logging.ERROR)
    error_handler.setFormatter(formatter)
    logger.addHandler(error_handler)

    signal_handler = SignalLogHandler(signals)
    signal_handler.setLevel(logging.INFO)
    signal_handler.setFormatter(formatter)
    logger.addHandler(signal_handler)
    return logger
