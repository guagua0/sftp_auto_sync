from __future__ import annotations

import fnmatch
import os
from pathlib import Path, PurePosixPath

from sftp_auto_sync.app.constants import DEFAULT_IGNORE_PATTERNS
from sftp_auto_sync.domain.models import SyncMapping


class PathMapper:
    def __init__(self, default_ignore_patterns: list[str] | None = None):
        self._default_ignore_patterns = list(default_ignore_patterns or DEFAULT_IGNORE_PATTERNS)

    @staticmethod
    def _normalize_abs(path: str | Path) -> Path:
        return Path(os.path.abspath(str(path)))

    @staticmethod
    def _root(mapping: SyncMapping) -> Path:
        return Path(os.path.abspath(mapping.local_dir))

    def is_under_root(self, mapping: SyncMapping, abs_path: str | Path) -> bool:
        root = self._root(mapping)
        candidate = self._normalize_abs(abs_path)
        try:
            common = os.path.commonpath([
                os.path.normcase(str(root)),
                os.path.normcase(str(candidate)),
            ])
        except ValueError:
            return False
        return common == os.path.normcase(str(root))

    def to_relative_path(self, mapping: SyncMapping, abs_path: str | Path) -> str:
        root = self._root(mapping)
        candidate = self._normalize_abs(abs_path)
        if not self.is_under_root(mapping, candidate):
            raise ValueError(f'{candidate} is outside mapping root {root}')
        rel = Path(os.path.relpath(candidate, root))
        rel_posix = PurePosixPath(rel.as_posix()).as_posix()
        if rel_posix in {'.', ''}:
            raise ValueError('Path resolves to mapping root, not a file.')
        return rel_posix

    def to_remote_path(self, mapping: SyncMapping, relative_path: str) -> str:
        return str(PurePosixPath(mapping.remote_dir) / PurePosixPath(relative_path))

    def is_ignored(self, mapping: SyncMapping, abs_path: Path) -> bool:
        patterns = [*self._default_ignore_patterns, *mapping.ignore_patterns]
        candidates: list[str] = []
        if self.is_under_root(mapping, abs_path):
            try:
                candidates.append(self.to_relative_path(mapping, abs_path))
            except ValueError:
                pass
        candidates.append(abs_path.name)
        candidates.append(PurePosixPath(abs_path.as_posix()).as_posix())
        for pattern in patterns:
            pattern = pattern.strip()
            if not pattern:
                continue
            for candidate in candidates:
                if fnmatch.fnmatch(candidate, pattern):
                    return True
                if '/' in candidate and PurePosixPath(candidate).match(pattern):
                    return True
        return False
