from __future__ import annotations

import logging

from sftp_auto_sync.domain.errors import ValidationError
from sftp_auto_sync.domain.models import SyncMapping
from sftp_auto_sync.infra.db.mapping_repo import MappingRepository
from sftp_auto_sync.services.validation_service import ValidationService


class MappingService:
    def __init__(self, mapping_repo: MappingRepository, validation_service: ValidationService, logger: logging.Logger | None = None):
        self._mapping_repo = mapping_repo
        self._validation_service = validation_service
        self._logger = logger or logging.getLogger(__name__)

    def list_all(self) -> list[SyncMapping]:
        return self._mapping_repo.list_all()

    def list_enabled(self) -> list[SyncMapping]:
        return self._mapping_repo.list_enabled()

    def get(self, mapping_id: int) -> SyncMapping | None:
        return self._mapping_repo.get(mapping_id)

    def save(self, mapping: SyncMapping) -> SyncMapping:
        errors = self._validation_service.validate_mapping(mapping, self._mapping_repo.list_all())
        if errors:
            raise ValidationError(errors)
        if mapping.id is None:
            mapping.id = self._mapping_repo.create(mapping)
        else:
            self._mapping_repo.update(mapping)
        return self._mapping_repo.get(mapping.id) or mapping

    def delete(self, mapping_id: int) -> None:
        self._mapping_repo.delete(mapping_id)
