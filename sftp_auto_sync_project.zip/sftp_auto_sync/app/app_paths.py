from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from sftp_auto_sync.app.constants import APP_SLUG


@dataclass(frozen=True, slots=True)
class AppPaths:
    root: Path
    db_path: Path
    known_hosts_path: Path
    logs_dir: Path
    cache_dir: Path


def default_app_root() -> Path:
    appdata = os.environ.get('APPDATA')
    if appdata:
        return Path(appdata) / APP_SLUG
    xdg_data = os.environ.get('XDG_DATA_HOME')
    if xdg_data:
        return Path(xdg_data) / APP_SLUG
    return Path.home() / '.local' / 'share' / APP_SLUG


def build_app_paths(root: str | Path | None = None) -> AppPaths:
    base = Path(root) if root is not None else default_app_root()
    base.mkdir(parents=True, exist_ok=True)
    logs_dir = base / 'logs'
    cache_dir = base / 'cache'
    logs_dir.mkdir(parents=True, exist_ok=True)
    cache_dir.mkdir(parents=True, exist_ok=True)
    known_hosts_path = base / 'known_hosts'
    if not known_hosts_path.exists():
        known_hosts_path.touch()
    return AppPaths(
        root=base,
        db_path=base / 'app.db',
        known_hosts_path=known_hosts_path,
        logs_dir=logs_dir,
        cache_dir=cache_dir,
    )
